package project;
import java.sql.*;
import java.util.*;
public class output {
	private String usr ="postgres";
	private String pwd ="yby0630";
	private String url ="jdbc:postgresql://localhost:5432/postgres";
	public class database {
		String cust;
		String prod;
		int day;
		int month;
		int year;
		String state;
		int quant;
	}
	public class select {
		String cust;
		String prod;
		float avg_quant_1;
		float avg_quant_2;
		float avg_quant_3;
	}
	public class mfStructure{
		String cust;
		String prod;
		float avg_quant_1;
		float sum_quant_1;
		int count_quant_1;
		float avg_quant_2;
		float sum_quant_2;
		int count_quant_2;
		float avg_quant_3;
		float sum_quant_3;
		int count_quant_3;
	}
	List<mfStructure> mf = new ArrayList<mfStructure>();
	List<select> output = new ArrayList<select>();
	public void scan() {
		try {
			Connection con = DriverManager.getConnection(url, usr, pwd);
			ResultSet rs;
			boolean more;
			Statement st = con.createStatement();
			String ret = "select * from sales";
			rs = st.executeQuery(ret);
			more=rs.next();
			while(more) {
				database db = new database();
				db.cust = rs.getString(1);
				db.prod = rs.getString(2);
				db.day = rs.getInt(3);
				db.month = rs.getInt(4);
				db.year = rs.getInt(5);
				db.state = rs.getString(6);
				db.quant = rs.getInt(7);
				if (db.year==2017||db.year==2018){
					if (db.state.equals("NY")&&db.month==1){
						boolean exist = false;
						for(int i=0; i<mf.size(); i++){
							if(db.cust.equals(mf.get(i).cust) &&db.prod.equals(mf.get(i).prod)){
								exist = true;
								mf.get(i).sum_quant_1 += db.quant;
								mf.get(i).count_quant_1++;
								if(mf.get(i).count_quant_1 != 0) {
									mf.get(i).avg_quant_1 = mf.get(i).sum_quant_1 / mf.get(i).count_quant_1;
								}
							}
						}
						if(exist == false){
							mfStructure newMf = new mfStructure();
							newMf.cust = db.cust;
							newMf.prod = db.prod;
							newMf.sum_quant_1 = db.quant;
							newMf.count_quant_1++;
							if(newMf.count_quant_1 != 0) {
								newMf.avg_quant_1 = newMf.sum_quant_1 / newMf.count_quant_1;
							}
							mf.add(newMf);
						}
					}
				}
				more = rs.next();
			}
			rs = st.executeQuery(ret);
			more=rs.next();
			while(more) {
				database db = new database();
				db.cust = rs.getString(1);
				db.prod = rs.getString(2);
				db.day = rs.getInt(3);
				db.month = rs.getInt(4);
				db.year = rs.getInt(5);
				db.state = rs.getString(6);
				db.quant = rs.getInt(7);
				if (db.year==2017||db.year==2018){
					if (db.state.equals("NJ")||db.state.equals("CA")){
						boolean exist = false;
						for(int i=0; i<mf.size(); i++){
							if(db.cust.equals(mf.get(i).cust) &&db.prod.equals(mf.get(i).prod)){
								exist = true;
								mf.get(i).sum_quant_2 += db.quant;
								mf.get(i).count_quant_2++;
								if(mf.get(i).count_quant_2 != 0) {
									mf.get(i).avg_quant_2 = mf.get(i).sum_quant_2 / mf.get(i).count_quant_2;
								}
							}
						}
						if(exist == false){
							mfStructure newMf = new mfStructure();
							newMf.cust = db.cust;
							newMf.prod = db.prod;
							newMf.sum_quant_2 = db.quant;
							newMf.count_quant_2++;
							if(newMf.count_quant_2 != 0) {
								newMf.avg_quant_2 = newMf.sum_quant_2 / newMf.count_quant_2;
							}
							mf.add(newMf);
						}
					}
				}
				more = rs.next();
			}
			rs = st.executeQuery(ret);
			more=rs.next();
			while(more) {
				database db = new database();
				db.cust = rs.getString(1);
				db.prod = rs.getString(2);
				db.day = rs.getInt(3);
				db.month = rs.getInt(4);
				db.year = rs.getInt(5);
				db.state = rs.getString(6);
				db.quant = rs.getInt(7);
				if (db.year==2017||db.year==2018){
					if (db.state.equals("CT")){
						boolean exist = false;
						for(int i=0; i<mf.size(); i++){
							if(db.cust.equals(mf.get(i).cust) &&db.prod.equals(mf.get(i).prod)){
								exist = true;
								mf.get(i).sum_quant_3 += db.quant;
								mf.get(i).count_quant_3++;
								if(mf.get(i).count_quant_3 != 0) {
									mf.get(i).avg_quant_3 = mf.get(i).sum_quant_3 / mf.get(i).count_quant_3;
								}
							}
						}
						if(exist == false){
							mfStructure newMf = new mfStructure();
							newMf.cust = db.cust;
							newMf.prod = db.prod;
							newMf.sum_quant_3 = db.quant;
							newMf.count_quant_3++;
							if(newMf.count_quant_3 != 0) {
								newMf.avg_quant_3 = newMf.sum_quant_3 / newMf.count_quant_3;
							}
							mf.add(newMf);
						}
					}
				}
				more = rs.next();
			}
			for(int i=0; i<mf.size(); i++){
				select result = new select();
				result.cust = mf.get(i).cust;
				result.prod = mf.get(i).prod;
				if(mf.get(i).avg_quant_1>mf.get(i).avg_quant_2&&mf.get(i).avg_quant_1>mf.get(i).avg_quant_3){
					result.avg_quant_1 = mf.get(i).avg_quant_1;
					result.avg_quant_2 = mf.get(i).avg_quant_2;
					result.avg_quant_3 = mf.get(i).avg_quant_3;
				}
				output.add(result);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void show() {
		System.out.printf("%-4s","cust\t");
		System.out.printf("%-4s","prod\t");
		System.out.printf("%-11s","avg_quant_1\t");
		System.out.printf("%-11s","avg_quant_2\t");
		System.out.printf("%-11s","avg_quant_3\t");
		System.out.printf("\n");
		System.out.printf("====\t====\t===========\t===========\t===========\t");
		for(int i=0; i<output.size(); i++) {
			System.out.printf("\n");
			System.out.printf("%-4s\t",output.get(i).cust);
			System.out.printf("%-4s\t",output.get(i).prod);
			System.out.printf("%-11s\t",output.get(i).avg_quant_1);
			System.out.printf("%-11s\t",output.get(i).avg_quant_2);
			System.out.printf("%-11s\t",output.get(i).avg_quant_3);
		}
	}
	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			System.out.println("Success loading Driver!");
		} catch(Exception exception) {
			System.out.println("Fail loading Driver!");
			exception.printStackTrace();
		}
		output op = new output();
		op.scan();
		op.show();
	}
}
