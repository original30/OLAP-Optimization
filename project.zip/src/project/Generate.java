package project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


public class Generate {
	
	public void generateCode() {
		File output = new File("/Users/yby/eclipse-workspace/project/src/project/output.java");
		try {
			PrintWriter w = new PrintWriter(output);
			w.print("package project;\n");
			w.print("import java.sql.*;\n");
			w.print("import java.util.*;\n");
			w.print("public class output {\n");
			w.print("\tprivate String usr =\"postgres\";\n");
			w.print("\tprivate String pwd =\"yby0630\";\n");
			w.print("\tprivate String url =\"jdbc:postgresql://localhost:5432/postgres\";\n");
			
			Read read = new Read();
			read.readFile("/Users/yby/eclipse-workspace/project/esql4.txt");	// File path
			
			
			// Generate class
			w.print("\tpublic class database {\n");
			w.print("\t\tString cust;\n");
			w.print("\t\tString prod;\n");
			w.print("\t\tint day;\n");
			w.print("\t\tint month;\n");
			w.print("\t\tint year;\n");
			w.print("\t\tString state;\n");
			w.print("\t\tint quant;\n");
			w.print("\t}\n");
			
			
			w.print("\tpublic class select {\n");
			for (int i=0; i<read.select_attribute.length; i++) {
				if (read.select_attribute[i].equals("cust") || read.select_attribute[i].equals("prod") || read.select_attribute[i].equals("state")) {
					w.print("\t\t" + "String " + read.select_attribute[i] + ";\n");
				} else {
					if(read.select_attribute[i].contains("avg") || read.select_attribute[i].contains("sum")) {
						w.print("\t\t" + "float " + read.select_attribute[i] + ";\n");
					}else {
						w.print("\t\t" + "int " + read.select_attribute[i] + ";\n");
					}
					
				}
			}
			w.print("\t}\n");
		
			
			w.print("\tpublic class mfStructure{\n");
			for (int i=0; i<read.grouping_attributes.length; i++) {
				if (read.grouping_attributes[i].equals("cust") || read.grouping_attributes[i].equals("prod") || read.grouping_attributes[i].equals("state")) {
					w.print("\t\t" + "String " + read.grouping_attributes[i] + ";\n");
				} else {
					w.print("\t\t" + "int " + read.grouping_attributes[i] + ";\n");
				}
			}
			List<String> exist_aggr = new ArrayList<>();
			for (int i=0; i<read.f_vect.length; i++) {
				if(read.f_vect[i].contains("avg")) {
					w.print("\t\t" + "float " + read.f_vect[i] + ";\n");
					String sum = read.f_vect[i].replace("avg", "sum");
					if(!exist_aggr.contains(sum)) {
						w.print("\t\t" + "float " + sum + ";\n");
						exist_aggr.add(sum);
					}
					String count = read.f_vect[i].replace("avg", "count");
					if(!exist_aggr.contains(count)) {
						w.print("\t\t" + "int " + count + ";\n");
						exist_aggr.add(count);
					}
				}else {
					if(!exist_aggr.contains(read.f_vect[i])) {
						if(read.f_vect[i].contains("avg") || read.f_vect[i].contains("sum")) {
							w.print("\t\t" + "float " + read.f_vect[i] + ";\n");
							exist_aggr.add(read.f_vect[i]);
						}else {
							w.print("\t\t" + "int " + read.f_vect[i] + ";\n");
							exist_aggr.add(read.f_vect[i]);
						}
					}
				}
			}
			w.print("\t}\n");
			
			
			w.print("\tList<mfStructure> mf = new ArrayList<mfStructure>();\n");
			w.print("\tList<select> output = new ArrayList<select>();\n");
			
			boolean gv0 = false;
			for(int i=0; i<read.select_attribute.length; i++) {
				if(read.select_attribute[i].contains("count_all")) gv0 = true;
			}

			
			w.print("\tpublic void scan() {\n");
			w.print("\t\ttry {\n");
			w.print("\t\t\tConnection con = DriverManager.getConnection(url, usr, pwd);\n");
			w.print("\t\t\tResultSet rs;\n");
			w.print("\t\t\tboolean more;\n");
			w.print("\t\t\tStatement st = con.createStatement();\n");	
			w.print("\t\t\tString ret = \"select * from sales\";\n");
			
			

			
	        // while loop for output file
			for(int i=0; i<read.n; i++) {
				w.print("\t\t\trs = st.executeQuery(ret);\n");
				w.print("\t\t\tmore=rs.next();\n");
				w.print("\t\t\twhile(more) {\n");
				w.print("\t\t\t\tdatabase db = new database();\n");
				w.print("\t\t\t\tdb.cust = rs.getString(1);\n");
				w.print("\t\t\t\tdb.prod = rs.getString(2);\n");
				w.print("\t\t\t\tdb.day = rs.getInt(3);\n");
				w.print("\t\t\t\tdb.month = rs.getInt(4);\n");
				w.print("\t\t\t\tdb.year = rs.getInt(5);\n");
				w.print("\t\t\t\tdb.state = rs.getString(6);\n");
				w.print("\t\t\t\tdb.quant = rs.getInt(7);\n");
				
				
				// Where clause
				if(read.where != "") {
					w.print("\t\t\t\tif (");
					boolean judge1 = false;
					if(read.where.contains("and")) {
						String[] where = read.where.split("and");
						for(int j=0; j<where.length; j++) {
							if (where[j].contains("prod=") || where[j].contains("state=") || where[j].contains("cust=")) {
								String[] cur = where[j].split("=");
								where[j] = where[j].replace(where[j], cur[0] + ".equals(\"" + cur[1] + "\")");
							}
							if (where[j].contains("prod<>") || where[j].contains("state<>") || where[j].contains("cust<>")) {
								judge1 = true;
								String[] cur = where[j].split("<>");
								where[j] = where[j].replace(where[j], cur[0] + ".equals(\"" + cur[1] + "\")");
							}
							if(where[j].contains("<>")) {
								where[j] = where[j].replace("<>", "!=");
							}
							if(where[j].contains("!=") || where[j].contains("==") || where[j].contains(">=") || where[j].contains("<=")) {
								
							}else if(read.where.contains("=")) {
								where[j] = where[j].replace("=", "==");
							}
							if(j<where.length-1) {
								if(judge1) {
									w.print("!db." + where[j] + "&&");
								}else {
									w.print("db." + where[j] + "&&");
								}
							}else {
								if(judge1) {
									w.print("!db." + where[j]);
								}else {
									w.print("db." + where[j]);
								}
							}
						}
					}
					else if(read.where.contains("or")) {
						String[] where = read.where.split("or");
						for(int j=0; j<where.length; j++) {
							if (where[j].contains("prod=") || where[j].contains("state=") || where[j].contains("cust=")) {
								String[] cur = where[j].split("=");
								where[j] = where[j].replace(where[j], cur[0] + ".equals(\"" + cur[1] + "\")");
							}
							if (where[j].contains("prod<>") || where[j].contains("state<>") || where[j].contains("cust<>")) {
								judge1 = true;
								String[] cur = where[j].split("<>");
								where[j] = where[j].replace(where[j], cur[0] + ".equals(\"" + cur[1] + "\")");
							}
							if(where[j].contains("<>")) {
								where[j] = where[j].replace("<>", "!=");
							}
							if(where[j].contains("!=") || where[j].contains("==") || where[j].contains(">=") || where[j].contains("<=")) {
								
							}else if(read.where.contains("=")) {
								where[j] = where[j].replace("=", "==");
							}
							if(j<where.length-1) {
								if(judge1) {
									w.print("!db." + where[j] + "||");
								}else {
									w.print("db." + where[j] + "||");
								}
							}else {
								if(judge1) {
									w.print("!db." + where[j]);
								}else {
									w.print("db." + where[j]);
								}
							}
						}
					}
					else {
						if (read.where.contains("prod=") || read.where.contains("state=") || read.where.contains("cust=")) {
							String[] cur = read.where.split("=");
							read.where = read.where.replace(read.where, cur[0] + ".equals(\"" + cur[1] + "\")");
						}
						if (read.where.contains("prod<>") || read.where.contains("state<>") || read.where.contains("cust<>")) {
							judge1 = true;
							String[] cur = read.where.split("<>");
							read.where = read.where.replace(read.where, cur[0] + ".equals(\"" + cur[1] + "\")");
						}
						if(read.where.contains("<>")) {
							read.where = read.where.replace("<>", "!=");
						}
						if(read.where.contains("!=") || read.where.contains("==") || read.where.contains(">=") || read.where.contains("<=")) {
							
						}else if(read.where.contains("=")) {
							read.where = read.where.replace("=", "==");
						}
						if(judge1) {
							w.print("!db." + read.where);
						}else {
							w.print("db." + read.where);
						}
					}
					w.print("){\n");
				}
				
				
				if(gv0 == true && i==0) {
					w.print("\t\t\t\t\tboolean count_exist = false;\n");
					w.print("\t\t\t\t\tfor(int i=0; i<mf.size(); i++){\n");
					w.print("\t\t\t\t\t\tif(");
					for(int j=0; j<read.grouping_attributes.length; j++) {
						String groupAttr = read.grouping_attributes[j];
						if(groupAttr.contains("cust") || groupAttr.contains("prod") || groupAttr.contains("state")) {
							if(j < read.grouping_attributes.length - 1) {
								w.print("db." + groupAttr + ".equals(mf.get(i)." + groupAttr + ") &&");
							}else {
								w.print("db." + groupAttr + ".equals(mf.get(i)." + groupAttr + ")");
							}
						}else {
							if(j < read.grouping_attributes.length - 1) {
								w.print("db." + groupAttr + "== mf.get(i)." + groupAttr + " &&");
							}else {
								w.print("db." + groupAttr + " == mf.get(i)." + groupAttr);
							}
						}
						
					}
					w.print("){\n");
					w.print("\t\t\t\t\t\t\tcount_exist = true;\n");
					w.print("\t\t\t\t\t\t\tmf.get(i).count_all++;\n");
					w.print("\t\t\t\t\t\t}\n");
					w.print("\t\t\t\t\t}\n");
					w.print("\t\t\t\t\tif(count_exist == false){\n");
					w.print("\t\t\t\t\t\tmfStructure newMf = new mfStructure();\n");
					w.print("\t\t\t\t\t\tnewMf.count_all++;\n");
					w.print("\t\t\t\t\t\tmf.add(newMf);\n");
					w.print("\t\t\t\t\t}\n");
				}
				
				
				
				// Such that clause
				w.print("\t\t\t\t\tif (");
				boolean judge2 = false;
				String selectVect = read.select_condition[i];
				selectVect = selectVect.replaceAll(" ", "");
				String s = String.valueOf(i+1);
				selectVect = selectVect.replaceAll("_", "");
				if(selectVect.contains("and")) {
					String[] scv = selectVect.split("and");
					for(int j=0; j<scv.length; j++) {
						scv[j] = scv[j].replaceFirst(s, "");
						if (scv[j].contains("prod=") || scv[j].contains("state=") || scv[j].contains("cust=")) {
							String[] cur = scv[j].split("=");
							scv[j] = scv[j].replace(scv[j], cur[0] + ".equals(" + cur[1] + ")");
						}
						if (scv[j].contains("prod<>") || scv[j].contains("state<>") || scv[j].contains("cust<>")) {
							judge2 = true;
							String[] cur = scv[j].split("<>");
							scv[j] = scv[j].replace(scv[j], cur[0] + ".equals(" + cur[1] + ")");
						}
						if(scv[j].contains("<>")) {
							scv[j] = scv[j].replace("<>", "!=");
						}
						if(scv[j].contains("!=") || scv[j].contains("==") || scv[j].contains(">=") || scv[j].contains("<=")) {
							
						}else if(scv[j].contains("=")) {
							scv[j] = scv[j].replace("=", "==");
						}
						if(j<scv.length-1) {
							if(judge2) {
								w.print("!db." + scv[j] + "&&");
							}else {
								w.print("db." + scv[j] + "&&");
							}
						}else {
							if(judge2) {
								w.print("!db." + scv[j]);
							}else {
								w.print("db." + scv[j]);
							}
						}
					}
				}
				else if(selectVect.contains("or")) {
					String[] scv = selectVect.split("or");
					for(int j=0; j<scv.length; j++) {
						scv[j] = scv[j].replaceFirst(s, "");
						if (scv[j].contains("prod=") || scv[j].contains("state=") || scv[j].contains("cust=")) {
							String[] cur = scv[j].split("=");
							scv[j] = scv[j].replace(scv[j], cur[0] + ".equals(" + cur[1] + ")");
						}
						if (scv[j].contains("prod<>") || scv[j].contains("state<>") || scv[j].contains("cust<>")) {
							judge2 = true;
							String[] cur = scv[j].split("<>");
							scv[j] = scv[j].replace(scv[j], cur[0] + ".equals(" + cur[1] + ")");
						}
						if(scv[j].contains("<>")) {
							scv[j] = scv[j].replace("<>", "!=");
						}
						if(scv[j].contains("!=") || scv[j].contains("==") || scv[j].contains(">=") || scv[j].contains("<=")) {
							
						}else if(scv[j].contains("=")) {
							scv[j] = scv[j].replace("=", "==");
						}
						if(j<scv.length-1) {
							if(judge2) {
								w.print("!db." + scv[j] + "||");
							}else {
								w.print("db." + scv[j] + "||");
							}
						}else {
							if(judge2) {
								w.print("!db." + scv[j]);
							}else {
								w.print("db." + scv[j]);
							}
						}
					}
				}
				else {
					selectVect = selectVect.replaceFirst(s, "");
					if (selectVect.contains("prod=") || selectVect.contains("state=") || selectVect.contains("cust=")) {
						String[] cur = selectVect.split("=");
						selectVect = selectVect.replace(selectVect, cur[0] + ".equals(" + cur[1] + ")");
					}
					if (selectVect.contains("prod<>") || selectVect.contains("state<>") || selectVect.contains("cust<>")) {
						judge2 = true;
						String[] cur = selectVect.split("<>");
						selectVect = selectVect.replace(selectVect, cur[0] + ".equals(" + cur[1] + ")");
					}
					if(selectVect.contains("<>")) {
						selectVect = selectVect.replace("<>", "!=");
					}
					if(selectVect.contains("!=") || selectVect.contains("==") || selectVect.contains(">=") || selectVect.contains("<=")) {
						
					}else if(selectVect.contains("=")) {
						selectVect = selectVect.replace("=", "==");
					}
					
					if(judge2) {
						w.print("!db." + selectVect);
					}else {
						w.print("db." + selectVect);
					}
				}
				w.print("){\n");
				w.print("\t\t\t\t\t\tboolean exist = false;\n");
				w.print("\t\t\t\t\t\tfor(int i=0; i<mf.size(); i++){\n");
				w.print("\t\t\t\t\t\t\tif(");
				
				
				// Group by clause
				for(int j=0; j<read.grouping_attributes.length; j++) {
					String groupAttr = read.grouping_attributes[j];
					if(groupAttr.contains("cust") || groupAttr.contains("prod") || groupAttr.contains("state")) {
						if(j < read.grouping_attributes.length - 1) {
							w.print("db." + groupAttr + ".equals(mf.get(i)." + groupAttr + ") &&");
						}else {
							w.print("db." + groupAttr + ".equals(mf.get(i)." + groupAttr + ")");
						}
					}else {
						if(j < read.grouping_attributes.length - 1) {
							w.print("db." + groupAttr + "== mf.get(i)." + groupAttr + " &&");
						}else {
							w.print("db." + groupAttr + " == mf.get(i)." + groupAttr);
						}
					}
					
				}
				w.print("){\n");
				w.print("\t\t\t\t\t\t\t\texist = true;\n");
				List<String> existAggr_true = new ArrayList<>();
				
				
				// Do aggregate function on the data read from database
				for(int j=0; j<read.f_vect.length; j++) {
					String vect = read.f_vect[j];
					if(vect.contains(String.valueOf(i+1))) {
						if(vect.contains("sum") && !existAggr_true.contains(vect)) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("sum", "");
							w.print("\t\t\t\t\t\t\t\tmf.get(i)." + vect + " += db." + fix + ";\n");
							existAggr_true.add(vect);
						}
						else if(vect.contains("avg")) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("avg", "");
							String vect_sum = vect.replace("avg", "sum");
							if(!existAggr_true.contains(vect_sum)) {
								w.print("\t\t\t\t\t\t\t\tmf.get(i)." + vect_sum + " += db." + fix + ";\n");
								existAggr_true.add(vect_sum);
							}
							String vect_count = vect.replace("avg", "count");
							if(!existAggr_true.contains(vect_count)) {
								w.print("\t\t\t\t\t\t\t\tmf.get(i)." + vect_count + "++;\n");
								existAggr_true.add(vect_count);
							}
							w.print("\t\t\t\t\t\t\t\tif(mf.get(i)." + vect_count + " != 0) {\n");
							w.print("\t\t\t\t\t\t\t\t\tmf.get(i)." + vect + " = mf.get(i)." + vect_sum + " / mf.get(i)." + vect_count + ";\n");
							w.print("\t\t\t\t\t\t\t\t}\n");
						}
						else if(vect.contains("max")) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("max", "");
							w.print("\t\t\t\t\t\t\t\tif(mf.get(i)." + vect + " < db." + fix + ") mf.get(i)." + vect + " = db." + fix + ";\n");
						}
						else if(vect.contains("min")) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("min", "");
							w.print("\t\t\t\t\t\t\t\tif(mf.get(i)." + vect + " > db." + fix + ") mf.get(i)." + vect + " = db." + fix + ";\n");
						}
						else if(vect.contains("count") && !existAggr_true.contains(vect)) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("count", "");
							w.print("\t\t\t\t\t\t\t\tmf.get(i)." + vect + "++;\n");
							existAggr_true.add(vect);
						}
					}
				}
				w.print("\t\t\t\t\t\t\t}\n");
				w.print("\t\t\t\t\t\t}\n");
				
				
				// Add tuple to mfStructure if it doesn't exist
				w.print("\t\t\t\t\t\tif(exist == false){\n");
				w.print("\t\t\t\t\t\t\tmfStructure newMf = new mfStructure();\n");
				for(int j=0; j<read.grouping_attributes.length; j++) {
					w.print("\t\t\t\t\t\t\tnewMf." + read.grouping_attributes[j] + " = db."  + read.grouping_attributes[j] + ";\n");
				}
				List<String> existAggr_false = new ArrayList<>();
				for(int j=0; j<read.f_vect.length; j++) {
					String vect = read.f_vect[j];
					if(vect.contains(String.valueOf(i+1))) {
						if(vect.contains("avg")) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("avg", "");
							String vect_sum = vect.replace("avg", "sum");
							if(!existAggr_false.contains(vect_sum)) {
								w.print("\t\t\t\t\t\t\tnewMf." + vect_sum + " = db." + fix + ";\n");
								existAggr_false.add(vect_sum);
							}
							String vect_count = vect.replace("avg", "count");
							if(!existAggr_false.contains(vect_count)) {
								w.print("\t\t\t\t\t\t\tnewMf." + vect_count + "++;\n");
								existAggr_false.add(vect_count);
							}
							w.print("\t\t\t\t\t\t\tif(newMf." + vect_count + " != 0) {\n");
							w.print("\t\t\t\t\t\t\t\tnewMf." + vect + " = newMf." + vect_sum + " / newMf." + vect_count + ";\n");
							w.print("\t\t\t\t\t\t\t}\n");
						}
						else if(vect.contains("count") && !existAggr_false.contains(vect)) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("count", "");
							w.print("\t\t\t\t\t\t\tnewMf." + vect + "++;\n");
							existAggr_true.add(vect);
						}
						else if(vect.contains("sum") && !existAggr_false.contains(vect)) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("sum", "");
							w.print("\t\t\t\t\t\t\tnewMf." + vect + " = db." + fix + ";\n");
							existAggr_false.add(vect);
						}
						else if(vect.contains("max")) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("max", "");
							w.print("\t\t\t\t\t\t\tnewMf." + vect + " = db." + fix + ";\n");
						}
						else if(vect.contains("min")) {
							String fix = vect.replace(String.valueOf(i+1), "");
							fix = fix.replaceAll("_", "");
							fix = fix.replace("min", "");
							w.print("\t\t\t\t\t\t\tnewMf." + vect + " = db." + fix + ";\n");
						}
					}
				}
				w.print("\t\t\t\t\t\t\tmf.add(newMf);\n");
				w.print("\t\t\t\t\t\t}\n");
				w.print("\t\t\t\t\t}\n");
				if(read.where != "") w.print("\t\t\t\t}\n");
				w.print("\t\t\t\tmore = rs.next();\n");
				w.print("\t\t\t}\n");
			}
	        
			
			// Having clause
			w.print("\t\t\tfor(int i=0; i<mf.size(); i++){\n");
			w.print("\t\t\t\tselect result = new select();\n");
			for(int i=0; i<read.grouping_attributes.length; i++) {
				w.print("\t\t\t\tresult." + read.grouping_attributes[i] + " = mf.get(i)."  + read.grouping_attributes[i] + ";\n");
			}
			if(read.having_condition != "") {
				w.print("\t\t\t\tif(");
				if(read.having_condition.contains("and")) {
					String[] having = read.having_condition.split("and");
					for(int i=0; i<having.length; i++) {
						if(having[i].contains("<>") ) {
							having[i] = having[i].replace("<>", "!=");
						}
						if(having[i].contains("sum") ) {
							having[i] = having[i].replaceAll("sum", "mf.get(i).sum");
						}
						if(having[i].contains("avg") ) {
							having[i] = having[i].replaceAll("avg", "mf.get(i).avg");
						}
						if(having[i].contains("max") ) {
							having[i] = having[i].replaceAll("max", "mf.get(i).max");
						}
						if(having[i].contains("min") ) {
							having[i] = having[i].replaceAll("min", "mf.get(i).min");
						}
						if(having[i].contains("count") ) {
							having[i] = having[i].replaceAll("count", "mf.get(i).count");
						}
						if(i < having.length-1) {
							w.print(having[i] + "&&");
						}else {
							w.print(having[i]);
						}
					}
				}
				else if(read.having_condition.contains("or")) {
					String[] having = read.having_condition.split("or");
					for(int i=0; i<having.length; i++) {
						if(having[i].contains("<>") ) {
							having[i] = having[i].replace("<>", "!=");
						}
						if(having[i].contains("sum") ) {
							having[i] = having[i].replaceAll("sum", "mf.get(i).sum");
						}
						if(having[i].contains("avg") ) {
							having[i] = having[i].replaceAll("avg", "mf.get(i).avg");
						}
						if(having[i].contains("max") ) {
							having[i] = having[i].replaceAll("max", "mf.get(i).max");
						}
						if(having[i].contains("min") ) {
							having[i] = having[i].replaceAll("min", "mf.get(i).min");
						}
						if(having[i].contains("count") ) {
							having[i] = having[i].replaceAll("count", "mf.get(i).count");
						}
						if(i < having.length-1) {
							w.print(having[i] + "||");
						}else {
							w.print(having[i]);
						}
					}
				}
				else {
					if(read.having_condition.contains("<>") ) {
						read.having_condition = read.having_condition.replace("<>", "!=");
					}
					if(read.having_condition.contains("sum") ) {
						read.having_condition = read.having_condition.replaceAll("sum", "mf.get(i).sum");
					}
					if(read.having_condition.contains("avg") ) {
						read.having_condition = read.having_condition.replaceAll("avg", "mf.get(i).avg");
					}
					if(read.having_condition.contains("max") ) {
						read.having_condition = read.having_condition.replaceAll("max", "mf.get(i).max");
					}
					if(read.having_condition.contains("min") ) {
						read.having_condition = read.having_condition.replaceAll("min", "mf.get(i).min");
					}
					if(read.having_condition.contains("count") ) {
						read.having_condition = read.having_condition.replaceAll("count", "mf.get(i).count");
					}
					w.print(read.having_condition);
				}
				w.print("){\n");
				for(int i=read.grouping_attributes.length; i<read.select_attribute.length; i++) {
					w.print("\t\t\t\t\tresult." + read.select_attribute[i] + " = mf.get(i)." + read.select_attribute[i] + ";\n");
				}
				w.print("\t\t\t\t}\n");
			}else {
				for(int i=read.grouping_attributes.length; i<read.select_attribute.length; i++) {
					w.print("\t\t\t\tresult." + read.select_attribute[i] + " = mf.get(i)." + read.select_attribute[i] + ";\n");
				}
			}
			w.print("\t\t\t\toutput.add(result);\n");
			w.print("\t\t\t}\n");
			w.print("\t\t} catch(Exception e) {\n");
			w.print("\t\t\te.printStackTrace();\n");
			w.print("\t\t}\n");
			w.print("\t}\n");
			
			
			// Show output table
			w.print("\tpublic void show() {\n");
			for(int i=0; i<read.select_attribute.length; i++) {
				w.print("\t\tSystem.out.printf(\"%-" + read.select_attribute[i].length() + "s\",\"" + read.select_attribute[i] + "\\t\");\n");
			}
			w.print("\t\tSystem.out.printf(\"\\n\");\n");
			w.print("\t\tSystem.out.printf(\"");
			for(int i=0; i<read.select_attribute.length; i++) {
				for (int j = 0; j < read.select_attribute[i].length(); j++) {
					w.print("=");
				}
				w.print("\\t");
			}
			w.print("\");\n");
			w.print("\t\tfor(int i=0; i<output.size(); i++) {\n");
			w.print("\t\t\tSystem.out.printf(\"\\n\");\n");
			for(int i=0; i<read.select_attribute.length; i++) {
				w.print("\t\t\tSystem.out.printf(\"%-" + read.select_attribute[i].length() + "s\\t\"," + "output.get(i)." + read.select_attribute[i] + ");\n");
			}
			w.print("\t\t}\n");
			w.print("\t}\n");
			
			
			// Main function
			w.print("\tpublic static void main(String[] args) {\n");
			w.print("\t\ttry {\n");
			w.print("\t\t\tClass.forName(\"org.postgresql.Driver\");\n");
			w.print("\t\t\tSystem.out.println(\"Success loading Driver!\");\n");
			w.print("\t\t} catch(Exception exception) {\n");
			w.print("\t\t\tSystem.out.println(\"Fail loading Driver!\");\n");
			w.print("\t\t\texception.printStackTrace();\n");  	
			w.print("\t\t}\n");
			w.print("\t\toutput op = new output();\n");
			w.print("\t\top.scan();\n");
			w.print("\t\top.show();\n");
			w.print("\t}\n");
			w.print("}\n");

			w.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
