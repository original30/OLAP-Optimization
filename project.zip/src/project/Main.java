package project;

public class Main {
	
	public static void main(String[] args) {
		Generate g = new Generate();
		g.generateCode();
		System.out.print("Success Generating file");
	}

}
