package project;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Read {
	public String[] select_attribute = null;
	public int n = 0;
	public String[] grouping_attributes = null;
	public String[] f_vect = null;
	public String[] select_condition = null;
	public String having_condition = null;
	public String where = null;
	
	public void readFile(String path) {
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(path));
			String line = reader.readLine();
			while (line != null) {
				if(line.contains("select_attribute")) {
					String input = line.substring(line.indexOf(":")+2, line.length());
					input = input.replaceAll(" ", "");
					select_attribute = input.split(",");
				}else if(line.contains("number_of_gv")) {
					String input = line.substring(line.indexOf(":")+2, line.length());
					input = input.replaceAll(" ", "");
					n = Integer.parseInt(input);
				}else if(line.contains("grouping_attributes")) {
					String input = line.substring(line.indexOf(":")+2, line.length());
					input = input.replaceAll(" ", "");
					grouping_attributes = input.split(",");
				}else if(line.contains("f-vect")) {
					String input = line.substring(line.indexOf(":")+2, line.length());
					input = input.replaceAll(" ", "");
					f_vect = input.split(",");
				}else if(line.contains("select_condition-vect")) {
					String input = line.substring(line.indexOf(":")+2, line.length());
					select_condition = input.split(",");
				}else if(line.contains("where")) {
					String input = line.substring(line.indexOf(":")+2, line.length());
					input = input.replaceAll(" ", "");
					where = input;
				}else if(line.contains("having_condition")) {
					String input = line.substring(line.indexOf(":")+2, line.length());
					input = input.replaceAll(" ", "");
					having_condition = input;
				}
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
